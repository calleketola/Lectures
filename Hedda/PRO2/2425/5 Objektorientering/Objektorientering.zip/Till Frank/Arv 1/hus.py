from byggnader import Hus, Skola


byggnader = [Hus(200,300), Skola(200,300,4,8)]

for i in range(len(byggnader)):
    print(byggnader[i].yta())

















        
