import paho.mqtt.client as mqtt
import time

def on_connect(client, userdata, flags, rc): # Called on connect
    print("Connected with result code "+str(rc))
    # Subscribe
    #topic = "cak"
    #client.subscribe(topic) # Subscribe to topic. I don't think this is necessary for this demo
    #print("Subscribed to", topic)

    send_test()
    

def on_message(client, userdata, msg):
    print(msg.topic+" "+str(msg.payload))

def send_test():
    # Send data to the broker
    time.sleep(1)
    client.publish("cak", "0 5")
    time.sleep(1)
    client.publish("cak", "1 7")
    time.sleep(1)
    client.publish("cak", "2 8")
    time.sleep(1)
    client.publish("cak", "3 1")

# Define the client
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

#client.connect("mqtt.eclipseprojects.io", 1833, 60) # Bad address

client.connect("broker.emqx.io", 1883)

client.loop_forever()


