import matplotlib.pyplot as plt
import paho.mqtt.client as mqtt

data_x = []
data_y = []

def on_connect(client, userdata, flags, rc): # Called on connect
    print("Successfully connected")
    topic = "cak"
    client.subscribe(topic) # Subscribe to topic
    print("Subscribed to", topic)

def on_message(client, userdata, msg):
    print(msg.topic, msg.payload) # Print recieved message
    point = msg.payload.split() # Messages will be on the form "x y"
    data_x.append(float(point[0])) # Convert to float
    data_y.append(float(point[1])) # Convert to float

    update_plot()

def create_plot():
    plt.ion() # Keeps the plot updating
    fig = plt.figure() # Creates the plot area
    ax = fig.add_subplot(111)
    line, = ax.plot(data_x, data_y) # Add data points
    fig.canvas.draw() # Draw plot
    fig.canvas.flush_events() # Update screen

    return fig, line, ax # These are needed outside the function

def update_plot():
    #print(data_x,data_y)
    line.set_data(data_x, data_y) # Update with the new data, this will slow as the data set increases
    ax.relim() # Adjust the axes
    ax.autoscale_view() # Adjust the view
    fig.canvas.draw() # Draw plot
    fig.canvas.flush_events() # Update screen
    

fig, line, ax = create_plot()

# Create and define the client
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect("broker.emqx.io", 1883)

client.loop_forever()


